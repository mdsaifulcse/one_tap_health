<!-- Favicon icon -->
<link rel="icon" href="{{asset('admin/assets/assets/images/favicon.ico')}}" type="image/x-icon">
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<!-- Required Fremwork -->
<link rel="stylesheet" type="text/css" href="{{asset('admin/assets/bower_components/bootstrap/dist/css/bootstrap.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('admin/assets/bower_components/sweetalert2/dist/sweetalert2.css')}}" rel="stylesheet" type="text/css" />
<!-- themify icon -->
<link rel="stylesheet" type="text/css" href="{{asset('admin/assets/icon/themify-icons/themify-icons.css')}}">
<!-- ico font -->
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/icon/icofont/css/icofont.css')}}">
<!-- flag icon framework css -->
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/pages/flag-icon/flag-icon.min.css')}}">
<!-- Menu-Search css -->
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/pages/menu-search/css/component.css')}}">
<!-- Horizontal-Timeline css -->
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/pages/dashboard/horizontal-timeline/css/style.css')}}">
<!-- amchart css -->
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/pages/dashboard/amchart/css/amchart.css')}}">
<!-- flag icon framework css -->
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/pages/flag-icon/flag-icon.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/bower_components/select2/dist/css/select2.min.css')}}">
<!-- Style.css -->
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/css/style.css')}}">
<!--color css-->
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/css/color/color-1.css')}}" id="color" />

<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/css/linearicons.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/css/simple-line-icons.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/css/ionicons.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('/admin/assets/css/jquery.mCustomScrollbar.css')}}">