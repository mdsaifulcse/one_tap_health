<script type="text/javascript" src="{{asset('admin/assets/bower_components/jquery/dist/jquery.min.js')}}"></script>
<script src="{{asset('admin/assets/bower_components/jquery-ui/jquery-ui.min.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/bower_components/tether/dist/js/tether.min.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/bower_components/bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="{{asset('admin/assets/bower_components/jquery-slimscroll/jquery.slimscroll.js')}}"></script>
<!-- modernizr js -->
<script type="text/javascript" src="{{asset('admin/assets/bower_components/modernizr/modernizr.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/bower_components/modernizr/feature-detects/css-scrollbars.js')}}"></script>
<!-- classie js -->
<script type="text/javascript" src="{{asset('admin/assets/bower_components/classie/classie.js')}}"></script>
<!-- Rickshow Chart js -->
<script src="{{asset('admin/assets/bower_components/d3/d3.js')}}"></script>
<script src="{{asset('admin/assets/bower_components/rickshaw/rickshaw.js')}}"></script>
<!-- Morris Chart js -->
<script src="{{asset('admin/assets/bower_components/raphael/raphael.min.js')}}"></script>
<script src="{{asset('admin/assets/bower_components/morris.js/morris.js')}}"></script>
<!-- Horizontal-Timeline js -->
<script type="text/javascript" src="{{asset('admin/assets/pages/dashboard/horizontal-timeline/js/main.js')}}"></script>
<!-- amchart js -->
<script type="text/javascript" src="{{asset('admin/assets/pages/dashboard/amchart/js/amcharts.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/pages/dashboard/amchart/js/serial.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/pages/dashboard/amchart/js/light.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/pages/dashboard/amchart/js/custom-amchart.js')}}"></script>
<!-- i18next.min.js -->
<script type="text/javascript" src="{{asset('admin/assets/bower_components/i18next/i18next.min.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/bower_components/i18next-xhr-backend/i18nextXHRBackend.min.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/bower_components/i18next-browser-languagedetector/i18nextBrowserLanguageDetector.min.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/bower_components/jquery-i18next/jquery-i18next.min.js')}}"></script>
{{--SweetAlert2--}}
<script type="text/javascript" src="{{asset('admin/assets/bower_components/sweetalert2/dist/sweetalert2.min.js')}}"></script>
<!-- Custom js -->
<script type="text/javascript" src="{{asset('admin/assets/pages/dashboard/custom-dashboard.js')}}"></script>
<script type="text/javascript" src="{{asset('admin/assets/js/script.js')}}"></script>

<!-- pcmenu js -->
<script src="{{asset('admin/assets/js/pcoded.min.js')}}"></script>
<script src="{{asset('admin/assets/js/demo-12.js')}}"></script>
<script src="{{asset('admin/assets/js/jquery.mCustomScrollbar.concat.min.js')}}"></script>
<script src="{{asset('admin/assets/js/jquery.mousewheel.min.js')}}"></script>
