<?php

return [
    'Book Title'=>'Book Title',
    'Book Title Bn'=>'বইয়ের শিরোনাম',
    'Category Name'=>'Category',
    'Category Name Bn'=>'বিভাগ/শ্রেণী',
    'Summery'=>'Summery',
];


?>