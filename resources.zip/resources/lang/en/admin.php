<?php

return [
    'Product Title'=>'Product Title',
    'Product Title Bn'=>'Product শিরোনাম',
    'Category Name'=>'Category',
    'Category Name Bn'=>'বিভাগ/শ্রেণী',
    'Sub Category Name'=>'Sub Category',
    'Third Category Name'=>'Third Category',
    'Specification'=>'Specification',
    'Third Sub-Category'=>'Third Sub-Category',
    'Summery'=>'Summery',
    'Related Products'=>'Related Products',
    'Product Specification & Summary'=>'Product Specification & Summary',
    'Description'=>'Description',
];


?>